$(document).ready(function(){
  $('.topnav').sticky();
});